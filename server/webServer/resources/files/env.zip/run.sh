#!/bin/bash
E="./slow"
eval $E $@
rm $E
