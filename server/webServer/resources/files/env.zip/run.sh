#!/bin/bash
E="./slow"
chmod +x $E
eval $E $@
rm $E
